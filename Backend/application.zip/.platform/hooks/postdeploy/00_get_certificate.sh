#!/usr/bin/env bash
sudo certbot -n -d rmit-marketing.ap-southeast-2.elasticbeanstalk.com --nginx --agree-tos --email rmitaiteam@gmail.com