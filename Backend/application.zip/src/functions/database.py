from src.config import DRIVER, HOST, USERNAME, PWD, RS_PORT, DATABASE
from sqlalchemy import create_engine

def create_rs_connection():
    # Build the SQLAlchemy database connection engine
    engine = create_engine(
        f'{DRIVER}://{USERNAME}:{PWD}@{HOST}:{RS_PORT}/{DATABASE}'
    )
    return engine
